<!--- Please provide a summary in the title and describe your issue here.
Is this a bug or feature request? If a bug, include all the steps that led to the issue.

If you're looking for help with your code, consider posting a question on StackOverflow instead:
http://stackoverflow.com/questions/tagged/spacy -->



## Your Environment
<!-- Include details of your environment -->
* Operating System: 
* Python Version Used: 
* spaCy Version Used: 
* Environment Information: 
